#a124_maze_spiral_[studentinitials].py

import turtle as trtl

wn = trtl.Screen()

wall_index = 0
config_walls_amnt = 25
config_walls_length = 10

trtl_index = 0
config_trtl_amnt = 25
config_trtl_length = 10

x = 0
y = 0

index_a = 1
def draw_maze(wall_index, config_wall_amnt, config_walls_length, x, y):
    trtl.penup()
    trtl.goto(x,y)

    while index_a == 1:
        if wall_index <= 25:
            trtl.pendown()
            trtl.forward(config_walls_length)
            trtl.left(90)
            config_walls_length = config_walls_length + 10
            wall_index = wall_index + 1
        else:
            x = 5
            y = 5
            trtl_escape(trtl_index, config_trtl_amnt, config_trtl_length, x, y)


def trtl_escape(trtl_index, config_trtl_amnt, config_trtl_length, x, y):
    trtl.penup()
    trtl.goto(x,y)
    while index_a == 1:
        if trtl_index <= 25:
            trtl.color("red")
            trtl.pendown()
            trtl.forward(config_trtl_length)
            trtl.left(90)
            config_trtl_length = config_trtl_length + 10
            trtl_index = trtl_index + 1


draw_maze(wall_index, config_walls_amnt, config_walls_length, x, y)

wn.listen()
trtl.mainloop()
